
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<graphics.h> 
#include<mmsystem.h>
#pragma comment(lib,"winmm.lib")
#define Row 10
#define Col 10
int map[Row][Col] = { 0 };
void draw(IMAGE img[]) {
	for (int i = 0; i < Row; i++) {
		for (int j = 0; j < Col; j++) {
			switch (map[i][j]) {
			case -10:putimage(64 * j, 64 * i, &img[0]); break;
			case -9:putimage(64 * j, 64 * i, &img[1]); break;
			case -8:putimage(64 * j, 64 * i, &img[2]); break;
			case -7:putimage(64 * j, 64 * i, &img[3]); break;
			case -6:putimage(64 * j, 64 * i, &img[4]); break;
			case -5:putimage(64 * j, 64 * i, &img[5]); break;
			case -4:putimage(64 * j, 64 * i, &img[6]); break;
			case -3:putimage(64 * j, 64 * i, &img[7]); break;
			case -2:putimage(64 * j, 64 * i, &img[8]); break;
			case -11:putimage(64 * j, 64 * i, &img[9]); break;
			case 10:putimage(64 * j, 64 * i, &img[10]); break;
			case 11:putimage(64 * j, 64 * i, &img[11]); break;
			default:putimage(64 * j, 64 * i, &img[10]); break; break;


			}

		}
	}
}
void play() {
	MOUSEMSG msg;
	while (1)
	{
		msg = GetMouseMsg(); 
		switch (msg.uMsg)
		{
		case WM_LBUTTONDOWN:
			if (map[msg.y / 64][msg.x / 64] >= -1)
				map[msg.y / 64][msg.x / 64] -= 10;
			return;
		}
	}
}
int win() {
	int lei = 0;
	for (int i = 0; i < Row; i++) {
		for (int j = 0; j < Col; j++) {
			if (map[i][j] < -1) {
				lei++;
			}
		}
	}
	return lei;
}
int lose() {
	for (int i = 0; i < Row; i++) {
		for (int j = 0; j < Col; j++) {
			if (map[i][j] == -11) {
				return 1;
			}
		}
	}
	return 0;
}
int main()
{
	int x, y,z;
	srand((unsigned)time(NULL));
	for (int i = 0; i < 20; ) {
		x = rand() % Row;
		y = rand() % Col;
		if (map[x][y] != -1) {
			map[x][y] = -1;
			i++;
		}
	}
	//����
	for (int i = 0; i < Row; i++) {
		for (int j = 0; j < Col; j++) {
			if (map[i][j] != -1) {
				for (int m = i-1; m<= i+1; m++)
				{
					for (int n = j - 1; n <= j +1; n++) {
						if (m >= 0 && m <=Row&&n >= 0 && n <=Col) {
							if (map[m][n]==-1)
							{
								map[i][j]++;
							}
						}
					}
				}
			}

		}
	 }
	//��ӡ
	/*for (int i = 0; i < Row; i++) {
		for (int j = 0; j < Col; j++) {
			printf("%d\t", map[i][j]);
		}
		printf("\n");
	}*/
	initgraph(64 * Col, 64 * Row);
	mciSendString(L"open ��������.mp3 alias back", 0, 0, 0);
	mciSendString(L"play back repeat",0,0,0);
	IMAGE img[12];
	loadimage(&img[0], _T("0.jpg"), 64, 64);
	loadimage(&img[1], _T("1.jpg"), 64, 64);
	loadimage(&img[2], _T("2.jpg"), 64, 64);
	loadimage(&img[3], _T("3.jpg"), 64, 64);
	loadimage(&img[4], _T("4.jpg"), 64, 64);
	loadimage(&img[5], _T("5.jpg"), 64, 64);
	loadimage(&img[6], _T("6.jpg"), 64, 64);
	loadimage(&img[7], _T("7.jpg"), 64, 64);
	loadimage(&img[8], _T("8.jpg"), 64, 64);
	loadimage(&img[9], _T("��.jpg"), 64, 64);
	loadimage(&img[10], _T("��.jpg"), 64, 64);
	loadimage(&img[11], _T("���.jpg"), 64, 64);
	draw(img);
	while (!lose())
	{
		play();
		draw(img);
		z = win();
		if (z == 80) {
			MessageBox(GetHWnd(), L"win", L"BOOM", MB_OK);
		}


	}
	MessageBox(GetHWnd(), L"SHAKALAKA", L"BOOM", MB_OK);
	getchar();
	return 0;
}