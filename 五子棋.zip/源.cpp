#include<stdio.h>
#include<graphics.h>
#include<stdlib.h>
#include<time.h>
#include <conio.h>
#include<mmsystem.h>
#pragma comment (lib,"winmm.lib")
void menu() {
	IMAGE BKIMG;
	IMAGE MENUIMG;
	loadimage(&BKIMG, "bkimage.jpg", 600, 500);
	loadimage(&MENUIMG, "image.jpg", 200, 50);
	putimage(0, 0, &BKIMG);
	for (int i = 0; i < 4; i++) {
		putimage(200, 80 + i * 50, &MENUIMG);
	}
	settextcolor(RED);
	settextstyle(25, 0, "����");
	setbkmode(TRANSPARENT);
	outtextxy(263,30,"������");
	outtextxy(250, 95, "��ʼ��Ϸ");
	outtextxy(250, 145, "��ϷȤζ");
	outtextxy(250, 195, "��Ϸ��ʷ");
	outtextxy(250, 245, "�˳���Ϸ");
	while (!_kbhit())
	{
		settextstyle(16, 0, "΢���ź�");
		settextcolor(RED);
		outtextxy(450,470, "�����������");
		Sleep(100);
		settextcolor(WHITE);
		outtextxy(450,470, "�����������");
		Sleep(100);
		settextcolor(BLACK);
		outtextxy(450,470, "�����������");
		Sleep(100);
		settextcolor(BLUE);
		outtextxy(450,470, "�����������");
		Sleep(100);
		settextcolor(YELLOW);
		outtextxy(450, 470, "�����������");
		Sleep(100);
	}
	getchar(); 
}
int play3(int chess[20][20] ,int folg){
	int a, s, d, low, row;
	for (a = 0; a < 20; a++) {
	for (s = 0; s < 20 - 4; s++) {
	low = row = 0;
	for (d = s; d < s + 5; d++) {
	if (chess[a][d] == folg) {
	low++;
	}
	if (chess[d][a] == folg) {
	row++;
	}
	}
	if (low == 5 || row == 5) {
	/*MessageBox(GetHWnd(), "win", "BOOM", MB_OK);*/
		return 1;
	}
	}
	}
	return 0;
}
int play4(int chess[20][20],int folg) {
	int a, s, d,row;
	for (a = 0; a < 20-4; a++) {
		for (s = 0; s < 20 - 4; s++) {
			row = 0;
			if (chess[a][s] == folg) {
				row++;
				for (d = 1; d < 5; d++) {
					if (chess[a + d][s + d] == folg) {
						row++;
					}

				}
				if (row == 5) {
					return 1;
				}
			}
		}
	}
	return 0;
}
int play5(int chess[20][20],int folg) {
	int a, s, d, row;
	for (a = 0; a <20-4; a++) {
		for (s = 19; s > 3; s--) {
			row = 0;
			if (chess[a][s] == folg) {
				row++;
				for (d = 1; d < 5; d++) {
					if (chess[a + d][s - d] == folg) {
						row++;
					}
				}
				if (row == 5) {
					return 1;
				}
			}
			
		}

	}
	return 0;
}
void play2() {
	int x, y,i,j;
	int black=0, white=0;
	int chess[20][20] = { 0 };
	while (true) {
		MOUSEMSG m = GetMouseMsg();
		switch (m.uMsg) {
		case WM_LBUTTONDOWN:
			if (m.x >= 10 && m.x <= 430 && m.y >= 10 && m.y <= 430)
			{
				x = m.x % 20;
				if (x <= 10)
					m.x = m.x - x;
				else
					m.x = m.x - x + 20;
				y = m.y % 20;
				if (y <= 10)
					m.y = m.y - y;
				else
					m.y = m.y - y + 20;
				i = m.x / 20;
				j = m.y / 20;
				if (chess[i][j] != 0)
					continue;
				setlinecolor(BLACK);
				setfillcolor(BLACK);
				fillcircle(m.x + 10, m.y + 10, 8);
				chess[i][j] = 2;
				/*int a, s, d, low, row;
				for (a = 0; a < 20; a++) {
					for (s = 0; s < 20 - 4; s++) {
						low = row = 0;
						for (d = s; d < s + 5; j++) {
							if (chess[a][d] == 2) {
								low++;
							}
							if (chess[d][a] == 2) {
								row++;
							}
						}
						if (low == 5 || row == 5) {
							MessageBox(GetHWnd(), "win", "BOOM", MB_OK);
						}
					}
				}*/
				if ((play3(chess, 2)) == 1 || (play4(chess, 2)) == 1 || (play5(chess, 2)) == 1) {
					MessageBox(GetHWnd(), "blackwin", "BOOM", MB_OK);
				}

			}
			break;
		case WM_RBUTTONDOWN:
			if (m.x >= 10 && m.x <= 430 && m.y >= 10 && m.y <= 430)
			{
				x = m.x % 20;
				if (x <= 10)
					m.x = m.x - x;
				else
					m.x = m.x - x + 20;
				y = m.y % 20;
				if (y <= 10)
					m.y = m.y - y;
				else
					m.y = m.y - y + 20;
				i = m.x / 20;
				j = m.y / 20;
				if (chess[i][j] != 0)
					continue;
				setlinecolor(WHITE);
				setfillcolor(WHITE);
				fillcircle(m.x + 10, m.y + 10, 8);
				chess[i][j] = 1;
				if ((play3(chess, 1)) == 1 || (play4(chess, 1)) == 1 || (play5(chess, 1)) == 1) {
					MessageBox(GetHWnd(), "whitewin", "BOOM", MB_OK);
				}
				break;
			}
		}
	}
}
void play() {
	IMAGE BKIMG;
	loadimage(&BKIMG, "bkimage.jpg", 600, 500);
	putimage(0, 0, &BKIMG);
	setlinecolor(BLACK);
	for (int i= 10; i < 430; i += 20) {
		line(10, i, 410, i);
		line(i, 10, i, 410);
	}
	play2();
}

int main() {
	initgraph(600, 500);
	mciSendString("open bkmusic.mp3 alias music", 0, 0, 0);
	mciSendString("play music repeat", 0, 0, 0);
	////loadimage(NULL, "1.jpg");//ֱ����ͼ
	//IMAGE img;
	//loadimage(&img, "1.jpg", 40, 50);
	//putimage(0, 0, &img);
	//line(0, 0, 600, 500);//����
	//circle(300, 250, 50);//��Բ
	//setfillcolor(RED);
	//fillcircle(100,100,50);//��ʵ��Բ
	//outtextxy(200, 200, "adaad");//�������
	menu();
	play();
	
	getchar();
	closegraph();
	return 0;
}