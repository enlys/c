#include<stdio.h>
#include<conio.h>
#include<Windows.h>
#include<graphics.h>
#include<mmsystem.h>
#pragma comment(lib,"winmm.lib")
#define Row 9
#define Col 11
#define SIZE 60
#define WINDOWWIDTH (SIZE*Col)
#define WINDOWHEIGHT (SIZE*Row)
IMAGE back, box, dbox, peo,end,wall,blank;
int map[Row][Col]={
	{0,1,1,1,1,1,1,1,1,1,0},
	{0,1,0,0,0,1,0,0,0,1,0},
	{0,1,0,4,4,4,4,4,0,1,0},
	{0,1,0,4,0,4,0,0,0,1,1},
	{0,1,0,0,0,5,0,0,4,0,1},
	{1,1,0,1,1,1,1,0,4,0,1},
	{1,0,0,3,3,3,3,1,0,0,1},
	{1,0,3,3,3,3,3,0,0,1,1},
	{1,1,1,1,1,1,1,1,1,1,0}
};
void game() {
	BeginBatchDraw();
	cleardevice();
	int r, c;
	for (int i = 0; i < Row; i++) {
		for (int j = 0; j < Col; j++)
		{
			if(map[i][j]==5||map[i][j]==8){
				r = i; c = j;
			}
		}
	}
	
	int ch;
	ch = _getch();
	switch (ch)
	{
	case 'W':
	case'w':
	case 72:
		if (map[r-1][c] == 0 || map[r-1][c] == 3) {
			map[r-1][c] += 5;
			map[r][c] -= 5;
		}
		else if (map[r-1][c] == 4 || map[r-1][c] == 7) {
			if (map[r-2][c] == 0 || map[r-2][c] == 3) {
				map[r-2][c] += 4;
				map[r-1][c] += 1;
				map[r][c] -= 5;

			}
		}
		break;
	case 'S':
	case's':
	case 80:
		if (map[r + 1][c] == 0 || map[r +1][c] == 3) {
			map[r + 1][c] += 5;
			map[r][c] -= 5;
		}
		else if (map[r + 1][c] == 4 || map[r + 1][c] == 7) {
			if (map[r + 2][c] == 0 || map[r + 2][c] == 3) {
				map[r + 2][c] += 4;
				map[r + 1][c] += 1;
				map[r][c] -= 5;

			}
		}
		break;
	case 'A':
	case'a':
	case 75:
		if (map[r][c - 1] == 0|| map[r][c - 1] == 3) {
			map[r][c - 1]+= 5;
			map[r][c] -= 5;
		}
		else if (map[r][c - 1] == 4 || map[r][c - 1] == 7) {
			if (map[r][c - 2] == 0 ||  map[r][c - 2] == 3) {
				map[r][c - 2] += 4;
				map[r][c - 1] += 1;
				map[r][c] -= 5;

			}
		}
		break;
	case 'D':
	case'd':
	case 77:
		if (map[r][c +1] == 0 || map[r][c + 1] == 3) {
			map[r][c + 1] += 5;
			map[r][c] -= 5;
		}
		else if (map[r][c + 1] == 4 || map[r][c + 1] == 7) {
			if (map[r][c + 2] == 0 || map[r][c + 2] == 3) {
				map[r][c + 2] += 4;
				map[r][c + 1] += 1;
				map[r][c] -= 5;

			}
		}
		break;
	}

}
void play() {
	for (int i = 0; i <Col; i++) {
		for (int j = 0; j <Row; j++)
		{
			switch (map[j][i])
			{
			case 0:putimage(i*SIZE, j*SIZE, &blank); break;
			case 1:putimage(i*SIZE, j*SIZE, &wall); break;
			case 3:putimage(i*SIZE, j*SIZE, &end); break;
			case 4:putimage(i*SIZE, j*SIZE, &box); break;
			case 5:putimage(i*SIZE, j*SIZE, &peo); break;
			case 7:putimage(i*SIZE, j*SIZE, &dbox); break;
			case 8:putimage(i*SIZE, j*SIZE, &peo); break;

			}
		}
		
	}
	EndBatchDraw();
}
void hua() {
	loadimage(&back, L"background.jpg", WINDOWWIDTH, WINDOWHEIGHT);
	loadimage(&box, L"box.jpg", SIZE,SIZE);
	loadimage(&dbox, L"Darkbox.jpg",SIZE,SIZE);
	loadimage(&peo, L"people.jpg", SIZE,SIZE);
	loadimage(&end, L"EndPoint.jpg", SIZE,SIZE);
	loadimage(&wall, L"Wall1.jpg", SIZE, SIZE);
	loadimage(&blank, L"blank.jpg", SIZE, SIZE);
	
}
int win() {
	int a=0;
	for (int i = 0; i < Col; i++) {
		for (int j = 0; j < Row; j++)
		{
			if (map[j][i] == 7)
				a++;
		}
	}
	return a;
}
int main() {
	/*for (int i = 0; i < Row; i++) {
		for (int j = 0; j < Col; j++)
		{
			switch (map[j][i])
			{
			case 0:printf("  "); break;
			case 1:printf("��"); break;
			case 3:printf("��"); break;
			case 4:printf("��"); break;
			case 5:printf("��"); break;
			
			}
		}
		printf("\n");
	}*/
	int x;
	initgraph(WINDOWWIDTH, WINDOWHEIGHT);
	mciSendString(L"open �㻹Ҫ������.mp3 alias back", 0, 0, 0);
	mciSendString(L"play back repeat", 0, 0, 0);
	hua();
	while (1) {
		//cleardevice();
		
		play();
		game();
		x = win();
		if (x == 9) {
			MessageBox(GetHWnd(), L"��ϲ����", L"win", MB_OK);
			closegraph();
		}
	}
	closegraph();
	getchar();
	return 0;
}