// SchoolManagementSystem.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include<stdio.h>
#include<graphics.h>
#include "student.h"
#include <mmsystem.h>
#pragma comment (lib,"winmm.lib")

int _tmain(int argc, _TCHAR* argv[])
{
	initgraph(600, 400);

	pf = fopen("StudentInfo.txt", "a+");
	mciSendString("open bkmusic.mp3 alias music", 0, 0, 0);
	mciSendString("play music repeat", 0, 0, 0);
	begin_init();
	head = init();

	//���ı�����������
	PNODE p = head;
	PNODE pnew = (PNODE)malloc(sizeof(NODE));

	while (fread(pnew, sizeof(struct node), 1, pf) != 0)
	{
		pnew->next = NULL;
		p->next = pnew;
		pnew = (PNODE)malloc(sizeof(NODE));
	}
	press();
	fclose(pf);

	return 0;
}

